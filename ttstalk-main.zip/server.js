const express = require('express');
const path    = require('path');
const { getAll } = require('./src/index');

const app  = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
(__dirname, 'public');
app.use(express.static(PUBLIC_DIR));

/**
 * POST /api/stalk
 * Body: { username: "apaaja_bebas" }
 * Response: { success, profile, videos, error }
 */
app.post('/api/stalk', async (req, res) => {
  // Content-Type JSON
  const { username } = req.body || {};

  if (!username || typeof username !== 'string' || !username.trim()) {
    return res.status(400).json({ success: false, error: 'Username tidak boleh kosong.' });
  }

  const clean = username.trim().replace(/^@/, '');

  try {
    const { profile, videos, error } = await getAll(clean);

    if (error) {
      return res.status(502).json({ success: false, error });
    }

    return res.json({ success: true, profile, videos });

  } catch (err) {
    return res.status(500).json({
      success: false,
      error: err.message || 'Internal server error',
    });
  }
});

app.get('*', (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
});


if (process.env.NODE_ENV !== 'production' || process.env.LISTEN === '1') {
  app.listen(PORT, () => {
    console.log(`TikScope berjalan di http://localhost:${PORT}`);
  });
}

module.exports = app;


// error fix sendiri
// banyak yang iri guys
// lihat" yang iri make ga 😂