const axios = require('axios');

const BASE_URL = 'https://tools.xrespond.com/api/tiktok/profile';

const CONFIG = {
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'Origin': 'https://tools.xrespond.com',
    'Referer': 'https://tools.xrespond.com/',
  },
  timeout: 15000,
};

/**
 * Ambil detail profil TikTok berdasarkan username.
 * @param {string} username
 * @returns {Promise<object>}
 */
async function getProfile(username) {
  const res = await axios.post(`${BASE_URL}/details`, { profile: username }, CONFIG);
  return res.data;
}

/**
 * Ambil daftar video TikTok berdasarkan username.
 * @param {string} username
 * @returns {Promise<object>}
 */
async function getVideos(username) {
  const res = await axios.post(`${BASE_URL}/videos`, { profile: username }, CONFIG);
  return res.data;
}

/**
 * Ambil semua data (profil + video) sekaligus secara paralel.
 * @param {string} username
 * @returns {Promise<{ profile: object|null, videos: object|null, error: string|null }>}
 */
async function getAll(username) {
  try {
    const [profileData, videoData] = await Promise.all([
      getProfile(username),
      getVideos(username).catch(() => null),
    ]);

    return {
      profile: profileData,
      videos: videoData,
      error: null,
    };
  } catch (err) {
    const message = err.response?.data?.message || err.response?.data || err.message || 'Unknown error';
    return {
      profile: null,
      videos: null,
      error: String(message),
    };
  }
}

module.exports = { getProfile, getVideos, getAll };
